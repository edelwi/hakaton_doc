#!/usr/bin/env python3

import requests
from rndflow import job
from functools import partial


def download_file(url, fname):
    res = requests.get(url, stream=True)
    res.raise_for_status()
    with open(fname, 'wb') as f:
        for chunk in res:
            f.write(chunk)

download_profiles = partial(
    download_file, 
    'https://cdn.myfitt.ru/ai/0b28bc4f-e643-4b87-8beb-7cb68c2ca39c/profiles.jsonl.gz'
    )

download_activity_hr = partial(
    download_file, 
    'https://cdn.myfitt.ru/ai/0b28bc4f-e643-4b87-8beb-7cb68c2ca39c/activity_hr.jsonl.gz'
    )

download_activity_step_ok = partial(
    download_file, 
    'https://cdn.myfitt.ru/ai/0b28bc4f-e643-4b87-8beb-7cb68c2ca39c/activity_step_ok.jsonl.gz'
    )

download_activity_step_cheaters = partial(
    download_file, 
    'https://cdn.myfitt.ru/ai/0b28bc4f-e643-4b87-8beb-7cb68c2ca39c/activity_step_cheaters.jsonl.gz'
    )

job.save_package(
    label='data',
    files={
            'profiles.jsonl.gz': download_profiles,
            'activity_hr.jsonl.gz': download_activity_hr,
            'activity_step_ok': download_activity_step_ok,
            'activity_step_cheaters': download_activity_step_cheaters,
        }
    )